export class Movies{
    moviesId:number;
    moviesName:string;
    moviesRating:number;
    moviesGenre:string;
    public constructor(moviesName:string,moviesRating:number,moviesGenre:string)
    {
        this.moviesName=moviesName;
        this.moviesRating=moviesRating;
        this.moviesGenre=moviesGenre;
    }
}